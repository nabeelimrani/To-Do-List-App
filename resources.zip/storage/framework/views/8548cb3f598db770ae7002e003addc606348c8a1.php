<?php $__env->startSection('content'); ?>
<div class="container dark-theme">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('To-Do List')); ?></div>

                <div class="card-body">
                    <form action="" method="">
                        <?php echo csrf_field(); ?>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Add a task" name="task_name" required>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">Add</button>
                            </div>
                        </div>
                    </form>

                  
                        <ul class="list-group">
                          
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <p>vkvkv</p>
                                    <form action="" method="POST">
                                        <?php echo csrf_field(); ?>
                                     
                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                    </form>
                                </li>
                          
                        </ul>
                    
                        <p>No tasks found.</p>
                  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\To-Do-List\resources\views/home.blade.php ENDPATH**/ ?>