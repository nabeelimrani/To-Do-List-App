<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
      body {
    font-family: 'Nunito', sans-serif;
    background-image: url('<?php echo e(asset('images/todowallpaper.jpg')); ?>');

   
    background-repeat: no-repeat;
}



        </style>
    </head>
    <body>
        <div class="container">
            <h1>Welcome to Laravel</h1>

            <div class="links">
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\wamp64\www\To-Do-List\resources\views/welcome.blade.php ENDPATH**/ ?>